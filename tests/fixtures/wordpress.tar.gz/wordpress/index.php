<?php
// Test fixture placeholder for the WordPress tarball.